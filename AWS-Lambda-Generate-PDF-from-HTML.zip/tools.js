const AWS = require('aws-sdk')
const lambda = new AWS.Lambda({
    region: 'eu-west-1'
})

module.exports.returnTimeInTimeZone = function returnTimeInTimeZone(timezoneString) {

    //var theTime = new Date (new Date().toLocaleString('en-GB', { timeZone: 'Europe/London' }));

    var theTime = new Date(new Date().toLocaleString(undefined, { timeZone: timezoneString })); // Europe/London
    return theTime
}

module.exports.updateParams = function generateUpdateParams(body) {

    var updateParam = {
        UpdateExpression: "set ",
        ExpressionAttributeValues: {}
    }
    Object.entries(body).map(([key, value]) => {
        updateParam.UpdateExpression += key + " = :" + key + ", "
        updateParam.ExpressionAttributeValues[":" + key] = value
    })
    // delete last `, ` characters
    updateParam.UpdateExpression = updateParam.UpdateExpression.slice(0, -2)
    return updateParam
}

module.exports.checkParameters = function checkParameters(eventParams) {
        var possibleFieldProps = [
            { fieldName: 'lang', type: 'string', required: true, possibleInputs: ["tr","en"] }, // string, number, object
            { fieldName: 'invoiceDate', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'invoiceId', type: 'number', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'restaurantName', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'specification', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'postCode', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'wasteOilCode', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'wasteOilLiters', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'wasteOilPayment', type: 'string', required: true, possibleInputs: [] }, // string, number, object
            { fieldName: 'products', type: 'object', required: true, possibleInputs: [] } // string, number, object
        ];
        
        // check for required fields first and ensure that the body contains them
    for (let fieldProps of possibleFieldProps) {
        if (fieldProps.required === true && (eventParams[fieldProps.fieldName] === undefined || eventParams[fieldProps.fieldName] == "")) {
            throw `${fieldProps.fieldName} field is required`
        }
    }

    // ensure that the body doesn't include any other fields than the fields defined above and their values types are correct
    for (let [key, value] of Object.entries(eventParams)) {
        const fieldProps = possibleFieldProps.find(fieldProps => fieldProps.fieldName === key)
        // check if exists
        if (!fieldProps) {
            throw `Invalid field '${key}'`
            // check if the type is correct
        }
        else if (fieldProps.type !== typeof value) {
            throw `'${key}' must be sent as '${fieldProps.type}'`
        }
    }

    // check possible Inputs
    for (let fieldProps of possibleFieldProps) {

        if (eventParams[fieldProps.fieldName] !== undefined && fieldProps.possibleInputs.length > 0 && (fieldProps.type === "string" || fieldProps.type === "number")) {
            var isInPossibleInputs = 0
            for (let theInput of fieldProps.possibleInputs) {
                if (eventParams[fieldProps.fieldName] === theInput) {
                    isInPossibleInputs = 1
                }
            }
            if (isInPossibleInputs === 0) {
                throw `Possible inputs for '${fieldProps.fieldName}' are '${fieldProps.possibleInputs}'`
            }
        }
    }
}

module.exports.createResponse = function createResponse(isError, response,language) {

    var errors = {}
    errors["noProducts_msg"] = {
        "en":"No products.",
        "tr":"Urun bulunamadi."
    }
    var res
    if (isError) {
        if (errors[response] === undefined || errors[response][language] === undefined) {
            errors[response] = {}
            errors[response][language] = response
        }
    }
    else {
        if (errors[response] !== undefined && errors[response][language] !== undefined) {
            response = errors[response][language]
        }
    }
    if (isError) {
        var errorString = errors[response][language]
        res = { error: "1", errorText: errorString }
    }
    else {
        res = { error: "0", errorText: "", response: response }
    }
    console.log('response:\n' + JSON.stringify(res))
    return res
}

module.exports.generateID = () => {
    var d = new Date().getTime();
    if (Date.now) {
        d = Date.now(); //high-precision timer
    }
    var uuid = 'xxxx-xxxx-xxxx-xxxx'.replace(/[xy]/g, function(c) {
        var r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
    return uuid;
}

/*
START
const AWS = require('aws-sdk');
var docClient = new AWS.DynamoDB.DocumentClient();
const tools = require("./tools.js")
let theTime = new Date()
theTime = theTime.toISOString()

exports.handler = async(event) => {

    var customerId
    if (event.params.customerId !== undefined) { customerId = event.params.customerId //admin request
    } else { customerId = event.userId } // customerRequest

  console.log('event:\n', JSON.stringify(event))
   event = event.params
   
   try { tools.checkParameters(event) }
  catch (error) { return tools.createResponse(true, error) }
  
  try { customers = await getCustomers() }
  catch (error) { return tools.createResponse(true, error.message) }
  if (!customers.Items) { return tools.createResponse(true, "customers were not found!") }
  
  return tools.createResponse(false, customers)
}

// ADD
function addBook(eventParam) {
eventParam.constant = "1"

        const params = {
            TableName: "Sketch_BookStyles",
            Item: eventParam
        }
        return docClient.put(params).promise()
}


// UPDATE
function updateOrder(updateExtraParams) {

  const params = {
    TableName: 'Sketch_Customers',
    Key: {
      customerId: event.customerId,
      orderId: event.orderId
    },
    ConditionExpression: "attribute_exists(orderId)",
    ReturnValues: 'ALL_NEW'
  }
  

  // append update parameters to params
  Object.assign(params, updateExtraParams)

  console.log('update parameters:\n' + JSON.stringify(params))
  return docClient.update(params).promise()
}

// QUERY
function getCustomers() {

  const params = {
    TableName: 'Sketch_Customers',
    IndexName = "constant-customerName-index",
    KeyConditionExpression: "constant = :cn",
    ExclusiveStartKey: exclusiveStartKey,
    ScanIndexForward : false, // true = ascending, false = descending
    Limit: pagingLimit,
    ExpressionAttributeValues: {
      ":cn": '1'
    }
  }
  console.log('params:\n', JSON.stringify(params))
  return docClient.query(params).promise()
}

// GET ITEM
function getUser() {
        const params = {
            TableName: 'Sketch_Customers',
            Key: {
                "customerId": customerId,
                "constant": "1"
            }
        }
        return docClient.get(params).promise()
    }

// DELETE
function deleteBook(eventParam) {

    const params = {
        TableName: "Sketch_BookStyles",
        Key: {
            "constant": "1",
            "bookStyleId": "10008"
        },
        ConditionExpression: "bookId >= :a",
        ExpressionAttributeValues: {
            ":a": 3
        }
    }
    return docClient.delete(params).promise()
}


*/


String.prototype.toDate = function(format) {
    var normalized = this.replace(/[^a-zA-Z0-9]/g, '-');
    var normalizedFormat = format.toLowerCase().replace(/[^a-zA-Z0-9]/g, '-');
    var formatItems = normalizedFormat.split('-');
    var dateItems = normalized.split('-');

    var monthIndex = formatItems.indexOf("mm");
    var dayIndex = formatItems.indexOf("dd");
    var yearIndex = formatItems.indexOf("yyyy");
    var hourIndex = formatItems.indexOf("hh");
    var minutesIndex = formatItems.indexOf("ii");
    var secondsIndex = formatItems.indexOf("ss");

    var today = new Date();

    var year = yearIndex > -1 ? dateItems[yearIndex] : today.getFullYear();
    var month = monthIndex > -1 ? dateItems[monthIndex] - 1 : today.getMonth() - 1;
    var day = dayIndex > -1 ? dateItems[dayIndex] : today.getDate();

    var hour = hourIndex > -1 ? dateItems[hourIndex] : today.getHours();
    var minute = minutesIndex > -1 ? dateItems[minutesIndex] : today.getMinutes();
    var second = secondsIndex > -1 ? dateItems[secondsIndex] : today.getSeconds();

    return new Date(year, month, day, hour, minute, second);
};
